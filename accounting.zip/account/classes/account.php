<?php
//Account Class

class Account {
	public $account_id;
	public $account_number;
	public $account_title;
	public $account_type;
	public $memo;
	
	function delete_account($account_id) { 
		if($_SESSION['user_type'] == 'admin') { 
			$query_jv = "SELECT * from transactions WHERE account_id='".$account_id."'";
			$retult_jv = mysqli_query($GLOBALS["___mysqli_ston"], $query_jv) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			$num_rows = mysqli_num_rows($retult_jv);
			if($num_rows > 0) { 
				return "This account have transactions. Please delete related JV's first by checking ledger then you can delete this account.";
			} else { 
				$del_query = mysqli_query($GLOBALS["___mysqli_ston"], 'DELETE from accounts WHERE account_id="'.$account_id.'"') or die(mysqli_error($GLOBALS["___mysqli_ston"]));
				return 'Account was deleted successfuly.';
			}
		} else { 
			return 'You have no permission to delete account.';
		}
	}//delete Account function ends here.
	
	function update_account($account_id, $account_number, $account_title, $account_type, $memo) {
		$account_check = "SELECT * from accounts where account_id='".$account_id."'";
		$account_check_result = mysqli_query($GLOBALS["___mysqli_ston"], $account_check) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		$account_check_rows = mysqli_num_rows($account_check_result);
		
		if($account_check_rows > 0) {
			$query = "UPDATE accounts SET
				account_number='".$account_number."',
				account_title='".$account_title."',
				account_type='".$account_type."',
				memo='".$memo."'
				WHERE account_id='".$account_id."'
			";	
			$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			return 'Account updated successfuly.';
		}//if account relates same company user is signed
	}//update account function ends here.
	
	function set_account($account_id) { 
		$query = "SELECT * from accounts WHERE account_id='".$account_id."'";
		$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		$row = mysqli_fetch_array($result);
		extract($row);
		
		$this->account_id = $account_id;
		$this->account_number = $account_number;
		$this->account_title = $account_title;
		$this->account_type = $account_type;
		$this->memo = $memo;		
	}//set account ends here.
	
	function list_accounts() { 
		if($_SESSION['user_type'] == 'admin') { 
			$query = "SELECT * from accounts ORDER by account_title ASC";
	} else { 
		echo 'Please add an account to list accounts.';
		exit();
	}	
	$options = '';
	$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			while($row = mysqli_fetch_array($result)) { 
				extract($row);
				$balance_query = "SELECT * from transactions WHERE account_id='".$account_id."'";
				$balance_result = mysqli_query($GLOBALS["___mysqli_ston"], $balance_query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
				$balance = 0;
				while($row_balance = mysqli_fetch_array($balance_result)) { 
					$balance = $balance+$row_balance['debit']+$row_balance['credit'];
				}
				$options .= '<tr>';
				$options .= '<td>'.$account_id.'</td>';
				$options .= '<td>'.$account_number.'</td>';
				$options .= '<td>'.$account_title.'</td>';
				$options .= '<td>'.$account_type.'</td>';
				if($balance < 0) {
				$options .= '<td style="color:red;">'.number_format($balance).'</td>';
				} else { 
				$options .= '<td>'.number_format($balance).'</td>';
				}
				$options .= '<td><form method="post" target="_blank" name="delete" action="reports/account_ledger.php">';
				$options .= '<input type="hidden" name="ledger_account" value="'.$account_id.'">';
				$options .= '<input type="submit" value="Ledger">';
				$options .= '</form></td>';
				if(partial_access('admin')) {
				$options .= '<td><form method="post" name="delete" action="manage_accounts.php">';
				$options .= '<input type="hidden" name="edit_account" value="'.$account_id.'">';
				$options .= '<input type="submit" value="Edit">';
				$options .= '</form></td>';
				$options .= '<td><form method="post" name="delete" onsubmit="return confirm_delete();" action="">';
				$options .= '<input type="hidden" name="delete_account" value="'.$account_id.'">';
				$options .= '<input type="submit" value="Delete">';
				$options .= '</form></td>';
				}
				$options .= '</tr>';
			} 
			echo $options;
	}//list_Accounts function ends here.
	
	function add_account($account_number, $account_title, $account_type, $memo) { 
			if($_SESSION['user_type'] == 'admin') {			
			$query = "INSERT into accounts(account_number, account_title, account_type, memo)
				VALUES('".$account_number."','".$account_title."','".$account_type."','".$memo."')";
				$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
				return 'Account was added successfuly!';
		} else { 
			return 'Logon to admin.';
		}
	}//add account ends here.
	
	function account_options() { 
			if($_SESSION['user_type'] != 'admin') {
			$query = "SELECT * from accounts";
				$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
				$options = '';
				while($row = mysqli_fetch_array($result)) { 
					extract($row);
					$options = '<option value="'.$account_id.'">'.$account_number.' | '.$account_title.'</option>';
				}//loop ends here.
				echo $options;
		} else { 
			return 'Logon to admin.';
		}
	}
}//Accounts class ends here.