<?php
class Jvs {
	public $date;
	public $jv_manual_id;
	public $jv_title;
	public $jv_description;
	public $jv_poster;
	public $jv_id;
	
	function delete_jvs($jv_id) {
		if($_SESSION['user_type'] == 'admin') { 
			//delete transactions.
			$del_tr = "DELETE from transactions WHERE jv_id='".$jv_id."'";
			$result_tr = mysqli_query($GLOBALS["___mysqli_ston"], $del_tr) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			//delete journal voucher.
			$query = "DELETE from journal_voucher WHERE jv_id='".$jv_id."'";
			$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			
			return 'Journal Voucher and related transactions removed successfuly.';
		} else { 
			return 'You cannot delete this JV.';
		}	
	}//jv delete Ends here.
	
	function transaction_row($jv_id) { 
		$query = "SELECT * from transactions WHERE jv_id='".$jv_id."' ORDER by tr_id DESC";
		$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		$credit = 0;
		$debit = 0;
		$balance = 0;
		$content = '';
		
		while($row = mysqli_fetch_array($result)) { 
			$content .= '<tr class="item-row">';
			//account query starts here to get account title.
			$account_query = "SELECT * from accounts WHERE account_id='".$row['account_id']."'";
			$account_result = mysqli_query($GLOBALS["___mysqli_ston"], $account_query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			$account_row = mysqli_fetch_array($account_result);
			//account query endsh ere.
		    $content .= '<td class="item-name">'.$account_row['account_title'].'</td>';
		    $content .= '<td class="description">'.$row['memo'].'</td>';
			if($row['debit'] == 0) {
		    	$content .= '<td>'.number_format($row['credit']).'</td>';
			} else { 
				$content .= '<td>'.number_format($row['debit']).'</td>';
			}
		  $content .= '</tr>';
		  $debit = $debit+$row['debit'];
		  $credit = $credit+$row['credit'];
		  $balance = $balance+$row['credit']+$row['debit'];
		}
		$content .= '<tr>
         	<td colspan="3" align="right">
            	Debit: <span id="debit_amnt">'.number_format($debit).'</span><br />
                Credit: <span id="credit_amnt">'.number_format($credit).'</span> <br />
                Balance:  <span id="balance_amnt">'.number_format($balance).'</span><br />
            </td>
         </tr>';
		 echo $content;
	}//transaction row ends here.
	
	function set_jvs($jv_id) {
		$query = "SELECT * from journal_voucher WHERE jv_id='".$jv_id."'";		
		$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		if(mysqli_num_rows($result) < 0) { 
			echo 'There is no such Voucher.';
			exit();
		}
		$row = mysqli_fetch_array($result);
		
		$this->jv_id = $row['jv_id'];
		$this->date = $row['date'];
		$this->jv_manual_id = $row['jv_id_manual'];
		$this->jv_title = $row['jv_title'];
		$this->jv_description = $row['jv_description'];
		//getting user name first and last.
			$query_user = "SELECT * from users WHERE user_id='".$row['user_id']."'";
			$result_user = mysqli_query($GLOBALS["___mysqli_ston"], $query_user) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			$row_user = mysqli_fetch_array($result_user);
			//end of getting user.
		$this->jv_poster = $row_user['first_name'].' '.$row_user['last_name']; 
	}//set jvs ends here.
	
	
	function list_jvs() { 
		$query = "SELECT * from journal_voucher  ORDER by jv_id DESC";
		$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		$content = '';
		while($row = mysqli_fetch_array($result)) { 
			extract($row);
			$content .= '<tr>';
			$content .= '<td>'.$date.'</td>';
			$content .= '<td>'.$jv_id_manual.'</td>';
			$content .= '<td>'.$jv_title.'</td>';
			$content .= '<td>'.$jv_description.'</td>';
			//getting user name first and last.
			$query_user = "SELECT * from users WHERE user_id='".$user_id."'";
			$result_user = mysqli_query($GLOBALS["___mysqli_ston"], $query_user) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			$row_user = mysqli_fetch_array($result_user);
			//end of getting user.
			$content .= '<td>'.$row_user['first_name'].' '.$row_user['last_name'].'</td>';
			//getting balance
			$amount_query = "SELECT SUM(debit) from transactions WHERE jv_id='".$jv_id."'";
			$result_amount = mysqli_query($GLOBALS["___mysqli_ston"], $amount_query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			$row = mysqli_fetch_array($result_amount);
			//end of getting balance of vouchar
			$content .= '<td>'.number_format($row['SUM(debit)']).' '.$_SESSION['currency'].'</td>';
			$content .= '<td><form target="_blank" method="post" name="view_jvs" action="view_jv.php">';
			$content .= '<input type="hidden" name="view_jv" value="'.$jv_id.'">';
			$content .= '<input type="submit" value="View">';
			$content .= '</form></td>';
			if(partial_access('admin')) {
			$content .= '<td><form method="post" onsubmit="return confirm_delete();" name="delete_jvs" action="">';
			$content .= '<input type="hidden" name="delete_jv" value="'.$jv_id.'">';
			$content .= '<input type="submit" value="Delete">';
			$content .= '</form></td>';
			}
			$content .= '</tr>';
		}
		echo $content;
	}//list_jv ends here.
	
	function jv_summary($from, $to) { 
		$query = "SELECT * from journal_voucher WHERE user_id='".$_SESSION['user_id']."' AND date between '".$from."' AND '".$to."' ORDER by jv_id ASC";
		$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		$content = '';
		$total = 0;
		while($row = mysqli_fetch_array($result)) { 
			extract($row);
			$content .= '<tr>';
			$content .= '<td>'.$jv_id.'</td>';
			$content .= '<td>'.$date.'</td>';
			$content .= '<td>'.$jv_id_manual.'</td>';
			$content .= '<td>'.$jv_title.'</td>';
			$content .= '<td>'.$jv_description.'</td>';
			//getting user name first and last.
			$query_user = "SELECT * from users WHERE user_id='".$user_id."'";
			$result_user = mysqli_query($GLOBALS["___mysqli_ston"], $query_user) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			$row_user = mysqli_fetch_array($result_user);
			//end of getting user.
			$content .= '<td>'.$row_user['first_name'].' '.$row_user['last_name'].'</td>';
			//getting balance
			$amount_query = "SELECT SUM(debit) from transactions WHERE jv_id='".$jv_id."'";
			$result_amount = mysqli_query($GLOBALS["___mysqli_ston"], $amount_query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			$row = mysqli_fetch_array($result_amount);
			//end of getting balance of vouchar
			$content .= '<td class="align_right">'.number_format($row['SUM(debit)']).' '.$_SESSION['currency'].'</td>';
			$content .= '</tr>';
			$total = $total+$row['SUM(debit)'];
		}
		$content .= '<tr>';
		$content .= '<th class="align_right" colspan="6">Total Amount</th>';
		$content .= '<th class="align_right">'.number_format($total).'</th>';
		$content .= '</tr>';
		echo $content;
	}//jv_summary ends here.
	
	function add_journal_voucher($date, $jv_manual_id, $jv_title, $jv_description) { 
			if($_SESSION['user_type'] != 'admin') {
		$query = "INSERT INTO `journal_voucher` (
				`jv_id` ,
				`date` ,
				`jv_id_manual` ,
				`jv_title` ,
				`jv_description` ,
				`user_id`
				)
				VALUES (
				NULL , '".$date."','".$jv_manual_id."', '".$jv_title."', '".$jv_description."', '".$_SESSION['user_id']."');";
				$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
				$jv_id = ((is_null($___mysqli_res = mysqli_insert_id($GLOBALS["___mysqli_ston"]))) ? false : $___mysqli_res);
				return $jv_id;
	}//add jvs
	
	function add_transaction($jv_id, $date, $account_id, $memo, $amount) {
			if($amount < 0) { 
				$credit = $amount;
				$debit = 0;
			} else { 
				$debit = $amount;
				$credit = 0;
			}
			$query = "INSERT INTO `transactions` (
					`tr_id` ,
					`jv_id` ,
					`account_id` ,
					`date` ,
					`memo` ,
					`debit` ,
					`credit`
					)
					VALUES (
					NULL, '".$jv_id."', '".$account_id."', '".$date."', '".$memo."', '".$debit."', '".$credit."'
					);";
			$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
	}//add transaction ends here.
	
	function transaction_summary($account_id, $from, $to) { 
		$query_op_bal = "SELECT SUM(debit), SUM(credit) from transactions WHERE account_id='".$account_id."' AND date < '".$from."'";
		$result_op_bal = mysqli_query($GLOBALS["___mysqli_ston"], $query_op_bal) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		$row_op_bal = mysqli_fetch_array($result_op_bal);
		$opening_balance = $row_op_bal['SUM(debit)']+$row_op_bal['SUM(credit)'];
		//opening balance ends here.
		
		$content = '<tr>
  				<td>&nbsp;</td>
  				<td>&nbsp;</td>
    			<td>&nbsp;</td>
			    <td>Opening balance</td>
    			<td class="align_right">&nbsp;</td>
    			<td class="align_right">&nbsp;</td>
			    <td class="align_right">'.number_format($opening_balance).'</td>
			    </tr>';
		$balance = $opening_balance;
		//opening balance row ends here.
		
		//getting transactions. 
		$query = "SELECT * from transactions WHERE account_id='".$account_id."' AND date between '".$from."' AND '".$to."' ORDER by tr_id ASC";
		$result = mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		while($row = mysqli_fetch_array($result)) {
			$balance = $balance+$row['debit']+$row['credit'];
			$content .= '<tr>';
  			$content .= '<td>'.$row['tr_id'].'</td>';
			$content .= '<td>'.$row['jv_id'].'</td>';
			$content .= '<td>'.$row['date'].'</td>';
			$content .= '<td>'.$row['memo'].'</td>';
			$content .= '<td class="align_right">'.number_format($row['debit']).'</td>';
			$content .= '<td class="align_right">'.number_format($row['credit']).'</td>';
			$content .= '<td class="align_right">'.number_format($balance).'</td>';
			$content .= '</tr>';	
		}//transactions loop ends.
		
		echo $content;
	}//trasnactions summary ends here.
	
	function accounts_summary($from, $to) {
		$account_query = "SELECT * from accounts WHERE user_id='".$_SESSION['user_id']."' ORDER by account_title ASC";
		$account_result = mysqli_query($GLOBALS["___mysqli_ston"], $account_query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		
		$content = '';
		$total_op_bal = 0;
		$total_debit = 0;
		$total_credit = 0;
		
		while($account_row = mysqli_fetch_array($account_result)) { 
			$query_op_bal = "SELECT SUM(debit), SUM(credit) from transactions WHERE account_id='".$account_row['account_id']."' AND date < '".$from."'";
			$result_op_bal = mysqli_query($GLOBALS["___mysqli_ston"], $query_op_bal) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
			$row_op_bal = mysqli_fetch_array($result_op_bal);
			$opening_balance = $row_op_bal['SUM(debit)']+$row_op_bal['SUM(credit)'];
			//opening balance ends here.	
		$total_op_bal = $opening_balance+$total_op_bal;
		
		$query_trans = "SELECT SUM(debit), SUM(credit) from transactions WHERE account_id='".$account_row['account_id']."' AND date between '".$from."' AND '".$to."'";
		$result_trans = mysqli_query($GLOBALS["___mysqli_ston"], $query_trans) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		$row_trans = mysqli_fetch_array($result_trans);
		//opening balance ends here.
		
		$content .= '<tr>';
		$content .= '<td scope="col" class="align_left">'.$account_row['account_id'].'</td>';
		$content .= '<td scope="col" class="align_left">'.$account_row['account_number'].'</td>';
		$content .= '<td scope="col" class="align_left">'.$account_row['account_title'].'</td>';
		$content .= '<td scope="col" class="align_left">'.$account_row['account_type'].'</td>';
		$content .= '<td scope="col" class="align_right">'.number_format($opening_balance).'</td>';
		$content .= '<td scope="col" class="align_right">'.number_format($row_trans['SUM(debit)']).'</td>';
		$content .= '<td scope="col" class="align_right">'.number_format($row_trans['SUM(credit)']).'</td>';
		$content .= '<td scope="col" class="align_right">';
		$content .= number_format($opening_balance+$row_trans['SUM(debit)']+$row_trans['SUM(credit)']);
		$content .= '</td>';
		$content .= '</tr>';
		
		$total_debit = $total_debit+$row_trans['SUM(debit)'];
		$total_credit = $total_credit+$row_trans['SUM(credit)'];
		}		
		$content .= '<tr>';
		$content .= '<th class="align_right" colspan="4">Total</th>';
		$content .= '<th class="align_right">'.number_format($total_op_bal).'</th>';
		$content .= '<th class="align_right">'.number_format($total_debit).'</th>';
		$content .= '<th class="align_right">'.number_format($total_credit).'</th>';
		$content .= '<th class="align_right" colspan="4">'.number_format($total_debit+$total_credit).'</th>';
		echo $content;
	}//accounts summary ends here.
	
		function trial_balance($from, $to) {
		$account_query = "SELECT * from accounts WHERE account_id='".$_SESSION['account_id']."' ORDER by account_type ASC";
		$account_result = mysqli_query($GLOBALS["___mysqli_ston"], $account_query) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		
		$content = '';
		$total_op_bal = 0;
		$total_debit = 0;
		$total_credit = 0;
		
		while($account_row = mysqli_fetch_array($account_result)) { 
		$query_trans = "SELECT SUM(debit), SUM(credit) from transactions WHERE account_id='".$account_row['account_id']."' AND date between '".$from."' AND '".$to."'";
		$result_trans = mysqli_query($GLOBALS["___mysqli_ston"], $query_trans) or die(mysqli_error($GLOBALS["___mysqli_ston"]));
		$row_trans = mysqli_fetch_array($result_trans);
		//opening balance ends here.
		
		$content .= '<tr>';
		$content .= '<td scope="col" class="align_left">'.$account_row['account_id'].'</td>';
		$content .= '<td scope="col" class="align_left">'.$account_row['account_number'].'</td>';
		$content .= '<td scope="col" class="align_left">'.$account_row['account_title'].'</td>';
		$content .= '<td scope="col" class="align_left">'.$account_row['account_type'].'</td>';
		$content .= '<td scope="col" class="align_right">';
		if(($row_trans['SUM(debit)']+$row_trans['SUM(credit)']) < 0) { 
			$tr_type = 'CR';
		} else { 
			$tr_type = 'DR';
		}
		$content .= number_format($row_trans['SUM(debit)']+$row_trans['SUM(credit)']).$tr_type;
		$content .= '</td>';
		$content .= '</tr>';
		
		$total_debit = $total_debit+$row_trans['SUM(debit)'];
		$total_credit = $total_credit+$row_trans['SUM(credit)'];
		}		
		$content .= '<tr>';
		$content .= '<th class="align_right" colspan="4">Total</th>';
		$content .= '<th class="align_right" colspan="4">'.number_format($total_debit+$total_credit).'</th></tr>';
		echo $content;
	}
	}
	//Trial Balance Ends here.
	
}//class ends here.