<?php
	include('system_load.php');
	//Including this file we load system.
	
	/*
	Logout function if called.
	*/
	if(isset($_GET['logout']) && $_GET['logout'] == 1) { 
		session_destroy();
		HEADER('LOCATION: index.php');
	} //Logout done.
	
	//user Authentication.
	authenticate_user('all');
	
	$new_user = new Users;//New user object.
	$new_level = new Userlevel;

	$page_title = "Dashboard"; //You can edit this to change your page title.
	require_once("includes/header.php"); //including header file.
	?>
			<div class="admin_wrap">
            	<?php require_once('includes/sidebar.php'); ?>
           
                <div class="alignleft rightcontent">
                    <h2 class="alignleft">System Information</h2>
                        <div class="clear"></div><!--clear float-->
                        <?php if(partial_access('admin')) { ?>
                        <div class="info_box userinfo alignleft">
                        	<h3>Users info</h3>
                            <hr />
                            <strong>Total Users:</strong> <?php $new_user->get_total_users('all');?> <br />
                            <strong>Active Users:</strong> <?php $new_user->get_total_users('activate');?> <br />
                            <strong>Deactive Users:</strong> <?php $new_user->get_total_users('deactivate');?> <br />
                            <strong>Ban Users:</strong> <?php $new_user->get_total_users('ban');?> <br />
                            <strong>Suspend Users:</strong> <?php $new_user->get_total_users('suspend');?> <br />
                            <p>You can manage users by going to users management <a href="users.php">Manage Users</a></p>
                        </div><!--users info ends here.-->
                        <?php } ?>

                        
                </div><!--rightcontent ends here.-->
            </div><!--admin wrap ends here.-->
                        
<?php
	require_once("includes/footer.php");
?>