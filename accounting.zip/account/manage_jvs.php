<?php
	include('system_load.php');
	//This loads system.
	//user Authentication.
	authenticate_user('subscriber');
	

	//new account object/
	$new_account = new Account;
	//new journal voucher object
	$new_jvs = new Jvs;
	
	
//add Journal Voucher Processing here.
if(isset($_POST['add_jv']) && $_POST['add_jv'] == '1') {
	extract($_POST);
	if($date == '') { 
		$message = 'Date is required.';
	} else if($jv_title == '') { 
		$message = 'Journal Voucher title is required.';
	}
	$balance = 0;
	foreach($amount as $amnt) { 
		$balance = $balance+$amnt;
	}
	if($balance != 0) { 
		$message = "Balance is not equal or zero. Please re enter.";
	} else if(sizeof($amount) != sizeof($account_id)) { 
		$message = "Accounts or Amounts does not match. Re Enter please.";
	}
	//jv processing here with saving jv id.
	$jv_id = $new_jvs->add_journal_voucher($date, $jv_manual_id, $jv_title, $jv_description);
	//transaction processing.
	if($jv_id == '' || $jv_id == 0){} else {
	$counter = 0;
	while($counter < sizeof($account_id)) {
		$new_jvs->add_transaction($jv_id, $date, $account_id[$counter], $memo[$counter], $amount[$counter]);
		$counter++;
	}
	HEADER('LOCATION: manage_jvs.php?message=Your entry was succesfuly entered.');
	}
}//end of JV Processing.
	

	require_once("includes/header.php"); //including header file.
?>
<style type="text/css">
.transactions table { border-collapse: collapse; }
.transactions table td, .transactions table th { border: 1px solid #CCCCCC; padding: 5px; }

.transactions textarea, .transactions input[type=text] {height:28px;}

.transactions {margin-top:30px;}
.transactions table {margin-top:8px;}
.transactions strong small {margin-left:345px; color:green;}
#items th { background: #eee; }

#debit_amnt, #credit_amnt, #balance_amnt {font-weight:bold;}
textarea:hover, textarea:focus, #items td.total-value textarea:hover, #items td.total-value textarea:focus, .delme:hover { background-color:#EEFF88; }

.delete-wpr { position: relative; }
.delme { display: block; color: #000; text-decoration: none; position: absolute; background: #EEEEEE; font-weight: bold; padding: 0px 3px; border: 1px solid; top: -6px; left: -22px; font-family: Verdana; font-size: 12px; }
</style>

			<div class="admin_wrap">
            	<?php require_once('includes/sidebar.php'); ?>
                <div class="alignleft rightcontent">
                	<?php
					//display message if exist.
						if(isset($message) && $message != '') { 
							echo '<div class="alert-box">';
							echo $message;
							echo '</div>';
						} else if(isset($_GET['message']) && $_GET['message'] != '') { 
							echo '<div class="alert-box">';
							echo $_GET['message'];
							echo '</div>';
						}
					?>
                	<h2 class="alignleft"><?php if(isset($_POST['edit_jv'])){ echo 'Edit Journal Voucher'; } else { echo 'Add New Journal Voucher';} ?></h2>
                	<div class="clear"></div><!--clear float-->
			<form name="add_jvs" id="add_jv" action="" method="post">
                <div class="journal">
                	<table width="680px" border="0" cellpadding="5">
                    	<tr>
                        	<th width="95px">Date*</th>
                            <td><input type="text" name="date" id="datepicker" required="required" readonly="readonly" value="<?php echo date("Y-m-d"); ?>" /></td>
                        	<th width="95px">JV Manual ID</th>
                            <td><input type="text" name="jv_manual_id" placeholder="Journal Voucher Manual Id" /></td>
                        </tr>
                        <tr>
                        	<th>JV Title*</th>
                            <td><input type="text" name="jv_title" placeholder="Voucher Title" required="required"  /></td>
                            <th>JV Description</th>
                            <td><textarea name="jv_description" placeholder="Voucher Description"></textarea></td>
                        </tr>
                    </table>
                </div><!--journal Ends here.-->
         <div class="transactions"> 
         <strong>Transactions <small>Include -(minus) symbol in start of credit amount.</small></strong>          
		<table id="items" width="680px">
		 <tr>
		      <th width="150">Account*</th>
		      <th width="380">Memo</th>
		      <th>Amount*</th>
		  </tr>
		  <tr class="item-row">
		      <td class="item-name"><div class="delete-wpr">
              <select class="account_id" name="account_id[]" required="required">
              	<option value="$account_id">Select Account</option>
                <?php $new_account->account_options(); ?>
              </select>
              </div></td>
		      <td class="description"><textarea name="memo[]" placeholder="Transaction Description"></textarea></td>
		      <td><input type="text" name="amount[]" class="amount" placeholder="Amount" required="required" /></td>
		  </tr>
		  
		  <tr>
		    <td colspan="3"><a id="addrow" href="javascript:;" title="Add a row">Add a row</a></td>
		  </tr>
		 <tr>
         	<td colspan="3" align="right">
            	Debit: <span id="debit_amnt">0.00</span><br />
                Credit: <span id="credit_amnt">0.00</span> <br />
                Balance:  <span id="balance_amnt">0.00</span><br />
            </td>
         </tr>
	</table>
    <input type="hidden" name="add_jv" value="1" />
    <input type="submit" value="Add entry" />
    </form>
    </div><!--transactions div-->
                    <script type="text/javascript">
						$(document).ready(function() {
							//update total function.
							function update_balance() { 
								debit_amnt = 0;
								credit_amnt = 0;
								balance_amnt = 0;
								i = 1;
									$('.amount').each(function(i){
										amount = parseInt($(this).val());
									if(amount < 0) {
										if(!isNaN(amount)) {
										credit_amnt = amount+credit_amnt;
										}
									} else { 
										if(!isNaN(amount)) {
										debit_amnt = amount+debit_amnt;
										}
									}
									$('#debit_amnt').html(debit_amnt);
									$('#credit_amnt').html(credit_amnt);
									$('#balance_amnt').html(debit_amnt+credit_amnt);
									});
							}//function update_balance Ends here.
						//calculations.
						$('#items').on('change', '.amount', function(){
							if(isNaN($(this).val())) {
								$(this).val('');
								alert('Please enter number.');
							}
							update_balance();
						});
						//Remove row.
						$('#items').on('click', '.delme', function() {
						   $(this).parents('.item-row').remove();
							update_balance();
						});
						//add row add here.
						$("#addrow").click(function(){
    					$(".item-row:last").after('<tr class="item-row"><td class="item-name"><div class="delete-wpr"><select class="account_id" name="account_id[]" required="required"><option value="">Select Account</option><?php $new_account->account_options(); ?></select><a class="delme" href="javascript:;" title="Remove row">X</a></div></td><td class="description"><textarea name="memo[]" placeholder="Transaction Description"></textarea></td><td><textarea name="amount[]" placeholder="Amount" class="amount" required="required"></textarea></td></tr>');
});
  			$('#add_jv').submit(function(e) {
				$('.amount').each(function() {
                    if($(this).val().length == 0) { 
						error = 1;
					} else { 
						error = 0;
					}
                });
				$('.account_id').each(function() {
                    if($(this).val().length == 0) { 
						error1 = 1;
					} else { 
						error1 = 0;
					}
                });
				if($('#balance_amnt').html() != "0") { 
					alert("Error: Voucher Balance is not 0(zero)");
					return false;
				} else if(error != 0) { 
					alert("All Amount fields are required.");
					return false;
				} else if(error1 != 0) { 
					alert("You have to select all accounts.");
					return false;
				}
			});
		});	
                    </script>
                </div>
                <div class="clear"></div><!--clear Float-->
            </div><!--admin wrap ends here.-->
                        
<?php require_once("includes/footer.php"); ?>