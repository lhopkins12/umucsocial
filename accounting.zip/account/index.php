<?php
	HEADER('LOCATION: login.php'); //You are redirecting to login page. You can change this page
	/*
	This page is doing nothing just redirecting you to login.php, You can change this page to anything you need.
	*/
?>