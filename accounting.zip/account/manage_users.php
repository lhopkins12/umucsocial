<?php
	include('system_load.php');
	//This loads system.
	
	//user Authentication.
	authenticate_user('admin');
	
	//User object.
	$new_user = new Users;
	//user level object
	$new_userlevel = new Userlevel;
	
	//update user submission.
	if(isset($_POST['edit_user']) && $_POST['edit_user'] != '') { 
		$new_user->set_user($_POST['edit_user'], $_SESSION['user_type'], $_SESSION['user_id']);
	}
	//setting user data if editing. 	
	
	//add user processing.
	if(isset($_POST['add_user']) && $_POST['add_user'] == '1') { 
		extract($_POST);
		if($first_name == '') { 
			$message = 'First name is required!';
		} else if($email == '') { 
			$message = 'Email is required!';
		} else if($password == ''){ 
			$message = 'Password Cannot be empty!';
		} else if($password != $confirm_password){ 
			$message = 'Password does not match!';
		} else if($status == '0') { 
			$message = 'Please select user status.';
		} else if($user_type == '0') { 
			$message = 'Please select user type.';
		}  else {
		$message = $new_user->add_user($first_name, $last_name, $date_of_birth, $address1, $address2, $city, $state, $country, $zip_code, $mobile, $phone, $email, $password, $description, $status, $user_type);
		}
	}//add user processing ends here.

	require_once("includes/header.php"); //including header file.
	?>
			<div class="admin_wrap">
            	<?php require_once('includes/sidebar.php'); ?>
                <div class="alignleft rightcontent">
                	<?php
					//display message if exist.
						if(isset($message) && $message != '') { 
							echo '<div class="alert-box">';
							echo $message;
							echo '</div>';
						}
					?>
                	<h2 class="alignleft"><?php if(isset($_POST['edit_user'])){ echo 'Edit user'; } else { echo 'Add New User';} ?></h2>
                	<div class="clear"></div><!--clear float-->
                    <form action="<?php $_SERVER['PHP_SELF']?>" id="add_user" name="user" method="post" enctype="multipart/form-data">
                    <table cellpadding="10" cellspacing="0" width="100%" border="0">
                    	<tr>
                        	<td width="150">First Name*</td>
                            <td><input type="text" name="first_name" placeholder="Enter first name" value="<?php echo $new_user->first_name; ?>" required="required" /></td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Last Name*</td>
                            <td><input type="text" name="last_name" placeholder="Enter last name" value="<?php echo $new_user->last_name; ?>" required="required" /></td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Date of birth</td>
                            <td><input type="text" name="date_of_birth" placeholder="Date of birth Format 2013-12-03" value="<?php echo $new_user->date_of_birth; ?>" /></td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Address 1</td>
                            <td><textarea name="address1" placeholder="Address line 1"><?php echo $new_user->address1; ?></textarea></td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Address 2</td>
                            <td><textarea name="address2" placeholder="Address line 2"><?php echo $new_user->address2; ?></textarea></td>
                        </tr>
                        
                        <tr>
                        	<td width="150">City</td>
                            <td><input type="text" name="city" placeholder="City" value="<?php echo $new_user->city; ?>" /></td>
                        </tr>
                        
                        <tr>
                        	<td width="150">State/Province</td>
                            <td><input type="text" name="state" placeholder="State or Province" value="<?php echo $new_user->state; ?>" /></td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Country</td>
                            <td><input type="text" name="country" placeholder="Your Country" value="<?php echo $new_user->country; ?>" /></td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Zip code</td>
                            <td><input type="text" name="zip_code" placeholder="Your zip code" value="<?php echo $new_user->zip_code; ?>" /></td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Mobile</td>
                            <td><input type="text" name="mobile" placeholder="Your Mobile Number" value="<?php echo $new_user->mobile; ?>" /></td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Phone</td>
                            <td><input type="text" name="phone" placeholder="Your phone number" value="<?php echo $new_user->phone; ?>" /></td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Email*</td>
                            <td><input type="text" name="email" placeholder="Your email address" value="<?php echo $new_user->email; ?>" required="required" /></td>
                        </tr>
                       <?php if(isset($_POST['edit_user'])) { ?> 
                        <tr>
                        	<td width="150">Password</td>
                            <td><input type="password" name="password" placeholder="Password" value="" /><small>Leave blank if you don't want to change password</small>                </td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Confirm Password</td>
                            <td><input type="password" name="confirm_password" placeholder="Confirm Password" value="" /></td>
                        </tr>
                        <?php } else {?>
                        <tr>
                        	<td width="150">Password*</td>
                            <td><input type="password" name="password" placeholder="Password" value="" required="required" />                </td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Confirm Password*</td>
                            <td><input type="password" name="confirm_password" placeholder="Confirm Password" value="" required="required" /></td>
                        </tr>
						<?php } ?>
                        <tr>
                        	<td width="150">Profile Image</td>
                            <td>
                            	<input type="file" name="profile_image" placeholder="Your profile image" />
                            	<?php
									if(isset($new_user->profile_image) && $new_user->profile_image != '') {
										echo '<a href="'.$new_user->profile_image.'" target="_blank"><img src="'.$new_user->profile_image.'" height="80" /></a><input type="hidden" name="already_img" value="'.$new_user->profile_image.'">';	
									}
								?>
                            </td>
                        </tr>
                        
                        <tr>
                        	<td width="150">Description</td>
                            <td><textarea name="description" placeholder="User Description"><?php echo $new_user->description; ?></textarea></td>
                        </tr>
                        <tr>
                        	<td width="150">Status*</td>
                            <td>
                            <select name="status" required="required" id="status" class="required">
									<option value="0">Select Status</option>
                                    <option <?php if($new_user->status == 'activate'){echo 'selected="selected"';} ?> value="activate">Activate</option>
                                    <option <?php if($new_user->status == 'deactivate'){echo 'selected="selected"';} ?> value="deactivate">Deactive</option>
                                    <option <?php if($new_user->status == 'ban'){echo 'selected="selected"';} ?> value="ban">Ban</option>
                                    <option <?php if($new_user->status == 'suspend'){echo 'selected="selected"';} ?> value="suspend">Suspend</option>                           	
	                            </select>
                              </td>
                        </tr>
                        
                        <tr>
                        	<td width="150">User Type*</td>
                            <td>
	                            <select name="user_type" required="required" id="user_type" class="required">
									<option value="">Select User Type</option>
                                    <option <?php if($new_user->user_type == 'admin'){echo 'selected="selected"';} ?> value="admin">Admin</option>
                                    <?php $new_userlevel->userlevel_options($new_user->user_type); ?>                          	
	                            </select>
                            </td>
                        </tr>
							  <?php 
						if(isset($_POST['edit_user'])){ 
							echo '<input type="hidden" name="edit_user" value="'.$_POST['edit_user'].'" />';
							echo '<input type="hidden" name="update_user" value="1" />'; 
						} else { 
							echo '<input type="hidden" name="add_user" value="1" />';
						} ?>
                        <tr>
                        	<td>&nbsp;</td>
                            <td><input type="submit" value="<?php if(isset($_POST['edit_user'])){ echo 'Update User'; } else { echo 'Add User';} ?>" /></td>
                        </tr>
                    </table>
                    </form>
                    <script type="text/javascript">
						$(document).ready(function() {
						// validate the register form
							$("#add_user").validate();
						});
                    </script>
                </div>
                <div class="clear"></div><!--clear Float-->
            </div><!--admin wrap ends here.-->
                        
<?php
	require_once("includes/footer.php");
?>