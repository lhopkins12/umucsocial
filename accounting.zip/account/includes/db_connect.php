<?php
//Database Connection file. Update with your Database information once you create database from cpanel, or mysql.
	define ("DB_HOST", "localhost"); //Databse Host.
	define ("DB_USER", "root"); //Databse User.
	define ("DB_PASS", ""); //database password.
	define ("DB_NAME", "accounting"); //database Name.
$dBlink = ($GLOBALS["___mysqli_ston"] = mysqli_connect(DB_HOST,  DB_USER,  DB_PASS));
if(!$dBlink) { 
	die("<h1>User cannot connect to server mysql Error. Please check includes/dbconnect.php</h1>");
}
$dBdb = mysqli_select_db( $dBlink, constant('DB_NAME'));
if(!$dBdb) { 
	die("<h1>User Could not select database please check includes/dbconnect.php</h1>");
}
?>