<div class="sidebar">
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <?php if(partial_access('admin')) { ?><li><a href="users.php">Users</a></li><?php } ?>
        <li><a href="accounts.php">Accounts</a></li>
        <li><a href="jvs.php">Journal Vouchers</a></li>
        <li><a href="#">Reports</a>
        	<ul>
            	<li><a href="reports/jv.php" target="_blank">Journal Vouchers</a></li>
                <li><a href="jvs.php?message=Please select a voucher.">Single Voucher</a></li>
                <li><a href="reports/ledger_summary.php" target="_blank">General Ledger summary</a></li>
                <li><a href="accounts.php?message=Please select an account.">Ledger by account</a></li>
                <li><a href="reports/trial_balance.php" target="_blank">Trial Balance</a></li>
            </ul>
        </li>
        <li><a href="dashboard.php?logout=1">Logout</a></li>
    </ul>
</div><!--sidebar Ends here.-->